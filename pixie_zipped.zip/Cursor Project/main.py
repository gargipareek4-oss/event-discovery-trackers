#!/usr/bin/env python3
"""
Event Discovery & Tracking Tool – Pixie Assignment.
Extracts events from BookMyShow (and optionally District), stores in Excel,
runs at intervals to add/update events and mark expired.
"""
import argparse
import sys
from pathlib import Path

# Allow running from repo root
sys.path.insert(0, str(Path(__file__).resolve().parent))

from src.config import load_config
from src.extractors.bookmyshow import BookMyShowExtractor
from src.storage.excel_store import ExcelEventStore


def run_once(city: str | None, output_file: str | None, config_path: str | None) -> int:
    """Fetch events for one city and update Excel. Returns exit code."""
    cfg = load_config(config_path)
    city = city or cfg.get("city") or "Mumbai"
    output_file = output_file or cfg.get("output_file") or "events.xlsx"
    store = ExcelEventStore(output_file)
    extractor = BookMyShowExtractor()
    try:
        events = extractor.fetch_events(city)
    except Exception as e:
        print(f"Error fetching events: {e}", file=sys.stderr)
        return 1
    if not events:
        print("No events returned; updating sheet with existing data (expiry only).")
    else:
        print(f"Fetched {len(events)} events for {city}.")
    try:
        store.upsert(events, mark_expired=True)
        print(f"Updated {output_file}.")
    except Exception as e:
        print(f"Error writing sheet: {e}", file=sys.stderr)
        return 1
    return 0


def list_cities() -> int:
    """Print available cities from BookMyShow."""
    extractor = BookMyShowExtractor()
    try:
        cities = extractor.get_cities()
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    print("Available cities (use name or code with --city):")
    for c in cities[:50]:
        print(f"  {c['name']} (code: {c['code']})")
    if len(cities) > 50:
        print(f"  ... and {len(cities) - 50} more")
    return 0


def run_scheduled(config_path: str | None) -> None:
    """Run job at regular intervals using schedule library."""
    import schedule
    cfg = load_config(config_path)
    interval_min = cfg.get("schedule_minutes") or 60
    schedule.every(interval_min).minutes.do(
        run_once,
        city=None,
        output_file=None,
        config_path=config_path,
    )
    print(f"Scheduled every {interval_min} minutes. Ctrl+C to stop.")
    run_once(None, None, config_path)
    while True:
        schedule.run_pending()
        import time
        time.sleep(60)


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Event Discovery & Tracking – fetch events and update Excel.",
    )
    parser.add_argument("--city", "-c", help="City name or region code (e.g. Mumbai)")
    parser.add_argument("--output", "-o", help="Output Excel file path (default: events.xlsx)")
    parser.add_argument("--config", help="Config YAML path (default: config.yaml)")
    parser.add_argument("--list-cities", action="store_true", help="List available cities and exit")
    parser.add_argument(
        "--schedule",
        action="store_true",
        help="Run every N minutes (N from config.schedule_minutes)",
    )
    args = parser.parse_args()
    if args.list_cities:
        return list_cities()
    if args.schedule:
        run_scheduled(args.config)
        return 0
    return run_once(args.city, args.output, args.config)


if __name__ == "__main__":
    sys.exit(main())
