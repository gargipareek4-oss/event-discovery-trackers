# Event Discovery & Tracking Tool – Pixie Assignment

Tool that extracts event data from **BookMyShow** (and optionally District), allows **city selection**, stores data in **Excel**, and runs at intervals to add new events, update existing ones, and mark expired events.

## Run as software (desktop app)

**Windows:** Double-click **`Run Event Tool.bat`** to open the GUI.  
**Or:** Run `python app.py` from the project folder.

The app lets you choose a city, fetch events, and open the Excel file from the window.

---

## Quick Start (command line)

```bash
# Clone and enter project
cd "e:\Cursor Project"

# Create virtualenv (recommended)
python -m venv venv
venv\Scripts\activate   # Windows
# source venv/bin/activate   # Linux/macOS

# Install dependencies
pip install -r requirements.txt

# Copy config and set city
copy config.example.yaml config.yaml
# Edit config.yaml: set city (e.g. Mumbai, Delhi, Bangalore)

# List available cities
python main.py --list-cities

# Run once for default city (from config)
python main.py

# Run for a specific city and output file
python main.py --city Mumbai --output events.xlsx

# Run on a schedule (every N minutes, N in config)
python main.py --schedule
```

## Cron (Linux/macOS)

To run every hour without keeping a process alive:

```bash
0 * * * * cd /path/to/project && /path/to/venv/bin/python main.py --city Mumbai >> cron.log 2>&1
```

Windows: use **Task Scheduler** to run `python main.py` at desired intervals.

## Project Structure

```
├── main.py                 # CLI entry: run once, list cities, schedule
├── config.example.yaml     # Config template (city, output_file, schedule_minutes)
├── requirements.txt
├── README.md
├── SUBMISSION.md           # 2-page submission content (export to PDF)
└── src/
    ├── config.py           # Load config (YAML)
    ├── extractors/
    │   ├── base.py         # EventRecord, BaseExtractor
    │   ├── bookmyshow.py   # BookMyShow via internal API (GETREGIONS, QUICKBOOK)
    │   └── district.py     # Stub for District scraping
    └── storage/
        └── excel_store.py  # Excel with dedup (source_id) and expiry handling
```

## Functional Requirements Covered

| Requirement | Implementation |
|-------------|----------------|
| **Data extraction** | BookMyShow internal API (`getData?cmd=GETREGIONS`, `QUICKBOOK&type=CT`). District: stub for future scraping. |
| **Fields** | event_name, date, venue, city, category, url, status, source, source_id, last_updated |
| **City selection** | `--city` or config; list via `--list-cities`; city name or region code. |
| **Storage** | Excel (openpyxl). Sheet "Events", columns as above. |
| **Deduplication** | By `source_id` (platform_event_id). Same ID = update row. |
| **Expiry** | On each run: events with date &lt; today get status = "expired". |
| **Scheduling** | `--schedule` (in-process) or cron / Task Scheduler. |
| **Error handling** | Try/except on fetch and write; clear error messages; graceful handling of missing/empty API response. |
| **Site changes** | Parser uses multiple possible key names for BMS response; adding a new extractor (e.g. District) is via `BaseExtractor`. |

## Tradeoffs

- **API vs scraping**: BookMyShow has no public API; we use its **internal** getData API (same as the website). More stable than HTML scraping but still unofficial; can break if BMS changes. District has no public API, so a full implementation would require scraping (see `src/extractors/district.py` stub).
- **Excel vs Google Sheets**: Excel keeps setup simple and runs locally; Google Sheets would need OAuth and `gspread` (or Sheets API) for a full prototype.
- **403 / blocking**: BookMyShow may return 403 for direct API calls (bot detection). The tool falls back to a small list of cities and sample events so the full pipeline (city → fetch → Excel → schedule) still runs for demo. In production you could use a proxy, browser automation, or official API if available.

## Build a standalone .exe (optional)

To get a single executable you can run without Python installed:

```bash
pip install pyinstaller
pyinstaller --onefile --windowed --name "EventDiscoveryTool" app.py
```

The `.exe` will be in `dist/`. Copy the whole project folder (or at least `config.yaml` and the `src/` folder) next to the exe if you use config; or run the exe from the project directory.

## Requirements

- Python 3.10+
- Dependencies: `requests`, `openpyxl`, `schedule`, `PyYAML`
