# Pixie – Full Stack Developer Intern Assignment  
## Event Discovery & Tracking Tool

---

## Mandatory Question (Yes/No)

- **Web scraping:** Yes – attempted scrapers for listing pages and used internal API (getData) for BookMyShow to avoid fragile HTML parsing.
- **Scheduled jobs / cron:** Yes – implemented in-process scheduling (`--schedule`) and documented cron / Task Scheduler for production.
- **Writing data to Excel / Google Sheets:** Yes – built Excel export with openpyxl; sheet structure, dedup, and expiry handling implemented.
- **Working with APIs:** Yes – used BookMyShow’s internal getData API (GETREGIONS, QUICKBOOK); designed extractors so District or other APIs can be added.

**Briefly:** Built a CLI tool that fetches events from BookMyShow by city, stores them in Excel with deduplication and expiry, and supports running at intervals via `--schedule` or cron.

---

## 1. Data Extraction

**Platforms:**  
- **BookMyShow** – used internal API `in.bookmyshow.com/serv/getData?cmd=` (GETREGIONS for cities, QUICKBOOK&type=CT for events). No HTML scraping.  
- **District** – stub only; no public API; design allows adding a scraper later.

**Fields collected:** event_name, date, venue, city, category, url, status, source, source_id, last_updated. Status is set to "expired" when event date is in the past.

---

## 2. City Selection Logic

- User sets city in `config.yaml` or via CLI `--city` (e.g. Mumbai, Delhi).  
- Tool resolves city name to region code using GETREGIONS; numeric input is treated as region code.  
- `--list-cities` prints available cities and codes from BookMyShow.

---

## 3. Data Storage

**Sheet structure:** Single sheet "Events" with columns: event_name, date, venue, city, category, url, status, source, source_id, last_updated.

**Deduplication:** By `source_id` (e.g. `bms_<EventCode>`). Each run merges new/updated events into existing rows; same source_id overwrites the row.

**Expiry handling:** On every run, existing rows with event date &lt; today are set to status = "expired" before writing. New fetches also set status from date.

---

## 4. Automation

**Scheduling:**  
- **Option A:** `python main.py --schedule` runs the job every N minutes (N in config).  
- **Option B:** Cron (Linux/macOS) or Task Scheduler (Windows) to run `python main.py` at fixed intervals.

**Update logic:** Each run (1) fetches current events for the chosen city, (2) loads existing Excel rows keyed by source_id, (3) marks past-dated events as expired, (4) merges fetched events into the map (add new, update existing), (5) writes all rows back to Excel.

---

## 5. Scalability & Reliability

**Handling site changes:**  
- BookMyShow parser accepts multiple possible JSON key names (e.g. EventTitle / name / Title) so minor response changes still work.  
- New platforms (e.g. District) are added as new extractors implementing the same interface; no change to storage or CLI.

**Error handling:**  
- Network/API errors raise with clear messages; CLI exits with non-zero code.  
- Missing or empty API response yields empty event list; sheet is still updated (expiry-only run).  
- Excel write errors are caught and reported.

---

## Deliverables

- **Repo:** Working tool in project folder; can be pushed to GitHub and link shared as required.  
- **Setup:** See README.md – venv, `pip install -r requirements.txt`, copy config, run `python main.py` or `python main.py --city Mumbai`.  
- **Run once:** `python main.py`  
- **Run on schedule:** `python main.py --schedule` or cron/Task Scheduler.

*(Keep this document to 2 pages when exporting to PDF for submission.)*
