"""Excel storage with deduplication and expiry handling."""
from datetime import datetime
from pathlib import Path
from typing import List

from openpyxl import Workbook, load_workbook

from ..extractors.base import EventRecord

HEADERS = [
    "event_name", "date", "venue", "city", "category", "url", "status",
    "source", "source_id", "last_updated",
]


class ExcelEventStore:
    """Store events in Excel with dedup by source_id and expiry handling."""

    def __init__(self, path: str | Path):
        self.path = Path(path)
        self._sheet_name = "Events"

    def _record_to_row(self, r: EventRecord) -> List[str]:
        return [
            r.event_name, r.date, r.venue, r.city, r.category, r.url, r.status,
            r.source, r.source_id, datetime.utcnow().strftime("%Y-%m-%d %H:%M"),
        ]

    def _row_to_record(self, row: List) -> EventRecord | None:
        if len(row) < 9:
            return None
        return EventRecord(
            event_name=str(row[0] or ""),
            date=str(row[1] or ""),
            venue=str(row[2] or ""),
            city=str(row[3] or ""),
            category=str(row[4] or "Event"),
            url=str(row[5] or ""),
            status=str(row[6] or "upcoming"),
            source=str(row[7] or "bookmyshow"),
            source_id=str(row[8] or ""),
        )

    def load_all(self) -> dict[str, EventRecord]:
        """Load existing rows keyed by source_id for deduplication."""
        existing = {}
        if not self.path.exists():
            return existing
        try:
            wb = load_workbook(self.path, read_only=True, data_only=True)
            if self._sheet_name not in wb.sheetnames:
                wb.close()
                return existing
            ws = wb[self._sheet_name]
            rows = list(ws.iter_rows(min_row=2, values_only=True))
            wb.close()
        except Exception:
            return existing
        for row in rows:
            if not row or row[0] is None:
                continue
            r = self._row_to_record(list(row))
            if r and r.source_id:
                existing[r.source_id] = r
        return existing

    def _mark_expired(self, records: dict[str, EventRecord], today: datetime) -> None:
        """Set status to 'expired' for events whose date is before today."""
        for r in records.values():
            if r.status == "expired":
                continue
            date_str = (r.date or "").strip()
            if not date_str:
                continue
            for fmt in ("%Y-%m-%d", "%d %b %Y", "%d/%m/%Y", "%Y%m%d"):
                try:
                    dt = datetime.strptime(date_str[:10], fmt)
                    if dt.date() < today.date():
                        r.status = "expired"
                    break
                except ValueError:
                    continue

    def upsert(self, new_events: List[EventRecord], mark_expired: bool = True) -> None:
        """
        Add new events and update existing by source_id.
        Deduplication: source_id is unique; same source_id overwrites.
        If mark_expired is True, existing rows with past dates get status=expired.
        """
        existing = self.load_all()
        today = datetime.now()
        if mark_expired:
            self._mark_expired(existing, today)
        for r in new_events:
            existing[r.source_id] = r
        rows = [HEADERS] + [self._record_to_row(r) for r in existing.values()]
        wb = Workbook()
        ws = wb.active
        ws.title = self._sheet_name
        for i, row in enumerate(rows, 1):
            for j, val in enumerate(row, 1):
                ws.cell(row=i, column=j, value=val)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        wb.save(self.path)
        wb.close()
