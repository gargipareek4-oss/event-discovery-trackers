"""Load config from YAML or env. Fallback if PyYAML not installed."""
from pathlib import Path

_config = None


def _load_yaml(path: Path) -> dict:
    try:
        import yaml
        with open(path, "r", encoding="utf-8") as f:
            return yaml.safe_load(f) or {}
    except ImportError:
        return {}
    except Exception:
        return {}


def load_config(config_path: str | Path | None = None) -> dict:
    global _config
    if _config is not None:
        return _config
    path = Path(config_path or "config.yaml")
    if not path.exists():
        path = Path("config.example.yaml")
    _config = _load_yaml(path)
    if not _config:
        _config = {
            "city": "Mumbai",
            "region_code": "",
            "output_file": "events.xlsx",
            "schedule_minutes": 60,
        }
    return _config
