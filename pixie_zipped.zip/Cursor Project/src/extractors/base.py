"""Base extractor interface for event platforms."""
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import List


@dataclass
class EventRecord:
    """Standard event record across platforms."""
    event_name: str
    date: str
    venue: str
    city: str
    category: str
    url: str
    status: str  # "upcoming" | "live" | "expired"
    source: str  # "bookmyshow" | "district"
    source_id: str  # platform-specific ID for deduplication


class BaseExtractor(ABC):
    """Abstract base for event data extractors."""

    @abstractmethod
    def get_cities(self) -> List[dict]:
        """Return list of {code, name} for city selection."""
        pass

    @abstractmethod
    def fetch_events(self, city_or_region: str) -> List[EventRecord]:
        """Fetch events for given city/region. city_or_region can be name or code."""
        pass
